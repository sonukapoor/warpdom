## warpdom

warpdom 208ad49e83, WPT 87b5d13099, Node v22.23.3, 2026-10-13T16:22:15.786Z, wall clock 485.7 s, timeout multiplier 1

| Directory | Files | Harness OK | All pass | Subtests | Passed | Pass rate | Score | Skipped |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| dom/ | 10 | 10 | 8 | 2102 | 1998 | 95.1% | 95.9% | 0 |
| dom/abort/ | 6 | 6 | 6 | 37 | 37 | 100.0% | 100.0% | 0 |
| dom/collections/ | 11 | 11 | 11 | 55 | 55 | 100.0% | 100.0% | 0 |
| dom/events/ | 89 | 82 | 64 | 702 | 587 | 83.6% | 78.4% | 13 |
| dom/events/non-cancelable-when-passive/ | 2 | 2 | 2 | 13 | 13 | 100.0% | 100.0% | 40 |
| dom/events/scrolling/ | 0 | 0 | 0 | 0 | 0 | - | - | 61 |
| dom/lists/ | 5 | 5 | 4 | 189 | 187 | 98.9% | 99.8% | 0 |
| dom/nodes/ | 258 | 254 | 233 | 9735 | 7180 | 73.8% | 92.4% | 0 |
| dom/nodes/Document-contentType/contentType/ | 15 | 14 | 4 | 15 | 4 | 26.7% | 26.7% | 0 |
| dom/nodes/insertion-removing-steps/ | 21 | 21 | 12 | 36 | 23 | 63.9% | 67.4% | 1 |
| dom/nodes/moveBefore/ | 54 | 38 | 0 | 138 | 3 | 2.2% | 0.2% | 5 |
| dom/observable/tentative/ | 0 | 0 | 0 | 0 | 0 | - | - | 27 |
| dom/ranges/ | 46 | 43 | 41 | 44494 | 40318 | 90.6% | 89.2% | 3 |
| dom/ranges/tentative/ | 0 | 0 | 0 | 0 | 0 | - | - | 19 |
| dom/traversal/ | 17 | 17 | 15 | 1607 | 1595 | 99.3% | 92.5% | 1 |
| **Total** | 534 | 503 | 400 | 59123 | 52000 | 88.0% | 78.0% | 170 |

## jsdom 30.1.2

warpdom 208ad49e83, WPT 87b5d13099, Node v22.23.3, 2026-10-13T16:30:21.582Z, wall clock 1021.8 s, timeout multiplier 1

| Directory | Files | Harness OK | All pass | Subtests | Passed | Pass rate | Score | Skipped |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| dom/ | 10 | 10 | 8 | 2041 | 1337 | 65.5% | 93.5% | 0 |
| dom/abort/ | 6 | 6 | 6 | 37 | 37 | 100.0% | 100.0% | 0 |
| dom/collections/ | 11 | 11 | 11 | 55 | 55 | 100.0% | 100.0% | 0 |
| dom/events/ | 89 | 78 | 65 | 702 | 468 | 66.7% | 79.5% | 13 |
| dom/events/non-cancelable-when-passive/ | 2 | 2 | 2 | 13 | 13 | 100.0% | 100.0% | 40 |
| dom/events/scrolling/ | 0 | 0 | 0 | 0 | 0 | - | - | 61 |
| dom/lists/ | 5 | 5 | 4 | 189 | 185 | 97.9% | 99.5% | 0 |
| dom/nodes/ | 258 | 242 | 222 | 9735 | 7118 | 73.1% | 89.2% | 0 |
| dom/nodes/Document-contentType/contentType/ | 15 | 3 | 2 | 15 | 2 | 13.3% | 13.3% | 0 |
| dom/nodes/insertion-removing-steps/ | 21 | 21 | 3 | 36 | 10 | 27.8% | 20.2% | 1 |
| dom/nodes/moveBefore/ | 54 | 38 | 0 | 138 | 3 | 2.2% | 0.2% | 5 |
| dom/observable/tentative/ | 0 | 0 | 0 | 0 | 0 | - | - | 27 |
| dom/ranges/ | 46 | 41 | 40 | 44494 | 40317 | 90.6% | 88.6% | 3 |
| dom/ranges/tentative/ | 0 | 0 | 0 | 0 | 0 | - | - | 19 |
| dom/traversal/ | 17 | 17 | 15 | 1607 | 1583 | 98.5% | 89.6% | 1 |
| **Total** | 534 | 474 | 378 | 59062 | 51128 | 86.6% | 74.3% | 170 |

## Side by side

| Directory | Files | Subtests | warpdom passed | warpdom rate | warpdom score | jsdom passed | jsdom rate | jsdom score |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| dom/ | 10 | 2102 | 1998 | 95.1% | 95.9% | 1337 | 63.6% | 93.2% |
| dom/abort/ | 6 | 37 | 37 | 100.0% | 100.0% | 37 | 100.0% | 100.0% |
| dom/collections/ | 11 | 55 | 55 | 100.0% | 100.0% | 55 | 100.0% | 100.0% |
| dom/events/ | 89 | 722 | 587 | 81.3% | 78.2% | 468 | 64.8% | 79.3% |
| dom/events/non-cancelable-when-passive/ | 2 | 13 | 13 | 100.0% | 100.0% | 13 | 100.0% | 100.0% |
| dom/lists/ | 5 | 189 | 187 | 98.9% | 99.8% | 185 | 97.9% | 99.5% |
| dom/nodes/ | 258 | 9735 | 7180 | 73.8% | 92.4% | 7118 | 73.1% | 89.2% |
| dom/nodes/Document-contentType/contentType/ | 15 | 15 | 4 | 26.7% | 26.7% | 2 | 13.3% | 13.3% |
| dom/nodes/insertion-removing-steps/ | 21 | 36 | 23 | 63.9% | 67.4% | 10 | 27.8% | 20.2% |
| dom/nodes/moveBefore/ | 54 | 138 | 3 | 2.2% | 0.2% | 3 | 2.2% | 0.2% |
| dom/ranges/ | 46 | 44494 | 40318 | 90.6% | 89.2% | 40317 | 90.6% | 88.6% |
| dom/traversal/ | 17 | 1607 | 1595 | 99.3% | 92.5% | 1583 | 98.5% | 89.6% |
| **Total** | 534 | 59143 | 52000 | 87.9% | 78.0% | 51128 | 86.4% | 74.2% |
