## warpdom

warpdom 208ad49e83, WPT 87b5d13099, Node v22.23.3, 2026-10-13T16:29:50.425Z, wall clock 111.3 s, timeout multiplier 1

| Directory | Files | Harness OK | All pass | Subtests | Passed | Pass rate | Score | Skipped |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| css/cssom/ | 250 | 236 | 128 | 4333 | 2880 | 66.5% | 64.3% | 11 |
| **Total** | 250 | 236 | 128 | 4333 | 2880 | 66.5% | 64.3% | 11 |

## jsdom 30.1.2

warpdom 208ad49e83, WPT 87b5d13099, Node v22.23.3, 2026-10-13T16:31:41.729Z, wall clock 243.7 s, timeout multiplier 1

| Directory | Files | Harness OK | All pass | Subtests | Passed | Pass rate | Score | Skipped |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| css/cssom/ | 250 | 238 | 133 | 4320 | 2878 | 66.6% | 63.8% | 11 |
| **Total** | 250 | 238 | 133 | 4320 | 2878 | 66.6% | 63.8% | 11 |

## Side by side

| Directory | Files | Subtests | warpdom passed | warpdom rate | warpdom score | jsdom passed | jsdom rate | jsdom score |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| css/cssom/ | 250 | 4333 | 2880 | 66.5% | 64.3% | 2878 | 66.4% | 63.8% |
| **Total** | 250 | 4333 | 2880 | 66.5% | 64.3% | 2878 | 66.4% | 63.8% |
