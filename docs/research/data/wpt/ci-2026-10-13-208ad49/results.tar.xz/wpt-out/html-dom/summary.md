## warpdom

warpdom 208ad49e83, WPT 87b5d13099, Node v22.23.3, 2026-10-13T16:28:11.824Z, wall clock 52.0 s, timeout multiplier 1

| Directory | Files | Harness OK | All pass | Subtests | Passed | Pass rate | Score | Skipped |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| html/dom/ | 22 | 21 | 3 | 67354 | 59298 | 88.0% | 72.5% | 3 |
| html/dom/documents/dom-tree-accessors/ | 37 | 35 | 34 | 219 | 201 | 91.8% | 94.8% | 1 |
| html/dom/documents/dom-tree-accessors/document.getElementsByName/ | 9 | 9 | 9 | 36 | 36 | 100.0% | 100.0% | 0 |
| html/dom/documents/resource-metadata-management/ | 8 | 7 | 6 | 20 | 17 | 85.0% | 83.9% | 0 |
| html/dom/elements/ | 1 | 0 | 0 | 1 | 0 | 0.0% | 0.0% | 0 |
| html/dom/elements/elements-in-the-dom/ | 2 | 2 | 2 | 9 | 9 | 100.0% | 100.0% | 0 |
| html/dom/elements/global-attributes/ | 44 | 43 | 31 | 250 | 234 | 93.6% | 75.0% | 3 |
| html/dom/elements/images/ | 1 | 0 | 0 | 1 | 0 | 0.0% | 0.0% | 0 |
| html/dom/elements/the-innertext-and-outertext-properties/ | 19 | 19 | 18 | 1404 | 1401 | 99.8% | 99.9% | 0 |
| html/dom/partial-updates/tentative/ | 0 | 0 | 0 | 0 | 0 | - | - | 7 |
| html/dom/partial-updates/tentative/fragment/ | 0 | 0 | 0 | 0 | 0 | - | - | 23 |
| html/dom/render-blocking/ | 0 | 0 | 0 | 0 | 0 | - | - | 62 |
| **Total** | 143 | 136 | 103 | 69294 | 61196 | 88.3% | 84.4% | 99 |

## jsdom 30.1.2

warpdom 208ad49e83, WPT 87b5d13099, Node v22.23.3, 2026-10-13T16:29:03.882Z, wall clock 106.4 s, timeout multiplier 1

| Directory | Files | Harness OK | All pass | Subtests | Passed | Pass rate | Score | Skipped |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| html/dom/ | 22 | 21 | 2 | 67338 | 52372 | 77.8% | 67.1% | 3 |
| html/dom/documents/dom-tree-accessors/ | 37 | 35 | 34 | 219 | 199 | 90.9% | 94.5% | 1 |
| html/dom/documents/dom-tree-accessors/document.getElementsByName/ | 9 | 9 | 8 | 36 | 35 | 97.2% | 88.9% | 0 |
| html/dom/documents/resource-metadata-management/ | 8 | 7 | 4 | 20 | 15 | 75.0% | 77.3% | 0 |
| html/dom/elements/ | 1 | 0 | 0 | 1 | 0 | 0.0% | 0.0% | 0 |
| html/dom/elements/elements-in-the-dom/ | 2 | 2 | 2 | 9 | 9 | 100.0% | 100.0% | 0 |
| html/dom/elements/global-attributes/ | 44 | 43 | 27 | 250 | 216 | 86.4% | 69.9% | 3 |
| html/dom/elements/images/ | 1 | 0 | 0 | 1 | 0 | 0.0% | 0.0% | 0 |
| html/dom/elements/the-innertext-and-outertext-properties/ | 19 | 19 | 0 | 1404 | 13 | 0.9% | 3.2% | 0 |
| html/dom/partial-updates/tentative/ | 0 | 0 | 0 | 0 | 0 | - | - | 7 |
| html/dom/partial-updates/tentative/fragment/ | 0 | 0 | 0 | 0 | 0 | - | - | 23 |
| html/dom/render-blocking/ | 0 | 0 | 0 | 0 | 0 | - | - | 62 |
| **Total** | 143 | 136 | 77 | 69278 | 52859 | 76.3% | 68.0% | 99 |

## Side by side

| Directory | Files | Subtests | warpdom passed | warpdom rate | warpdom score | jsdom passed | jsdom rate | jsdom score |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| html/dom/ | 22 | 67355 | 59298 | 88.0% | 72.5% | 52372 | 77.8% | 67.1% |
| html/dom/documents/dom-tree-accessors/ | 37 | 219 | 201 | 91.8% | 94.8% | 199 | 90.9% | 94.5% |
| html/dom/documents/dom-tree-accessors/document.getElementsByName/ | 9 | 36 | 36 | 100.0% | 100.0% | 35 | 97.2% | 88.9% |
| html/dom/documents/resource-metadata-management/ | 8 | 20 | 17 | 85.0% | 83.9% | 15 | 75.0% | 77.3% |
| html/dom/elements/ | 1 | 1 | 0 | 0.0% | 0.0% | 0 | 0.0% | 0.0% |
| html/dom/elements/elements-in-the-dom/ | 2 | 9 | 9 | 100.0% | 100.0% | 9 | 100.0% | 100.0% |
| html/dom/elements/global-attributes/ | 44 | 250 | 234 | 93.6% | 75.0% | 216 | 86.4% | 69.9% |
| html/dom/elements/images/ | 1 | 1 | 0 | 0.0% | 0.0% | 0 | 0.0% | 0.0% |
| html/dom/elements/the-innertext-and-outertext-properties/ | 19 | 1404 | 1401 | 99.8% | 99.9% | 13 | 0.9% | 3.2% |
| **Total** | 143 | 69295 | 61196 | 88.3% | 84.4% | 52859 | 76.3% | 68.0% |
