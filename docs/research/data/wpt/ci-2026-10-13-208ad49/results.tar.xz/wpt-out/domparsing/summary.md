## warpdom

warpdom 208ad49e83, WPT 87b5d13099, Node v22.23.3, 2026-10-13T16:29:39.934Z, wall clock 24.2 s, timeout multiplier 1

| Directory | Files | Harness OK | All pass | Subtests | Passed | Pass rate | Score | Skipped |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| domparsing/ | 36 | 32 | 24 | 498 | 334 | 67.1% | 86.1% | 2 |
| domparsing/tentative/ | 0 | 0 | 0 | 0 | 0 | - | - | 37 |
| **Total** | 36 | 32 | 24 | 498 | 334 | 67.1% | 86.1% | 39 |

## jsdom 30.1.2

warpdom 208ad49e83, WPT 87b5d13099, Node v22.23.3, 2026-10-13T16:30:04.147Z, wall clock 41.9 s, timeout multiplier 1

| Directory | Files | Harness OK | All pass | Subtests | Passed | Pass rate | Score | Skipped |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| domparsing/ | 36 | 31 | 25 | 498 | 335 | 67.3% | 84.9% | 2 |
| domparsing/tentative/ | 0 | 0 | 0 | 0 | 0 | - | - | 37 |
| **Total** | 36 | 31 | 25 | 498 | 335 | 67.3% | 84.9% | 39 |

## Side by side

| Directory | Files | Subtests | warpdom passed | warpdom rate | warpdom score | jsdom passed | jsdom rate | jsdom score |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| domparsing/ | 36 | 498 | 334 | 67.1% | 86.1% | 335 | 67.3% | 84.9% |
| **Total** | 36 | 498 | 334 | 67.1% | 86.1% | 335 | 67.3% | 84.9% |
